import React, { useState } from 'react';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword, GoogleAuthProvider, signInWithPopup } from 'firebase/auth';
import { auth } from '../../firebase/config';
import { Leaf, Mail, Lock, LogIn } from 'lucide-react';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e) => {
    if (e) e.preventDefault();
    setLoading(true);
    setError('');
    try {
      await signInWithEmailAndPassword(auth, email, password);
    } catch (err) {
      console.error(err);
      if (err.code === 'auth/configuration-not-found') {
        setError("Firebase configuration error. Please ensure Email/Password auth is enabled in the Firebase Console.");
      } else if (err.code === 'auth/invalid-credential') {
        setError("Invalid credentials. Please check your email and password.");
      } else {
        setError(err.message || "Failed to login. Please check your credentials.");
      }
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setLoading(true);
    setError('');
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
    } catch (err) {
      console.error(err);
      setError(err.message || "Failed to sign in with Google.");
    } finally {
      setLoading(false);
    }
  };

  const handleDemoAccount = async () => {
    const demoEmail = 'demo@compost.com';
    const demoPassword = 'password123';
    setEmail(demoEmail);
    setPassword(demoPassword);
    
    // Automatically trigger login with a slight delay so user can see it filled
    setTimeout(() => {
      setLoading(true);
      signInWithEmailAndPassword(auth, demoEmail, demoPassword)
        .catch(err => {
          console.error(err);
          setError("Demo login failed. Make sure Email/Password auth is enabled.");
          setLoading(false);
        });
    }, 500);
  };

  return (
    <div style={{ 
      display: 'flex', 
      justifyContent: 'center', 
      alignItems: 'center', 
      minHeight: '80vh' 
    }}>
      <div className="glass-panel fade-in" style={{ 
        width: '100%', 
        maxWidth: '400px', 
        padding: '40px',
        textAlign: 'center'
      }}>
        <div style={{ 
          background: 'var(--accent-primary)', 
          width: '60px',
          height: '60px',
          borderRadius: '16px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          margin: '0 auto 20px'
        }}>
          <Leaf color="white" size={32} />
        </div>
        <h1 style={{ marginBottom: '8px' }}>Welcome Back</h1>
        <p style={{ color: 'var(--text-secondary)', marginBottom: '32px' }}>Smart Compost Management System</p>

        {error && <div style={{ 
          color: 'var(--danger)', 
          background: 'rgba(248, 81, 73, 0.1)', 
          padding: '10px', 
          borderRadius: '6px', 
          marginBottom: '20px',
          fontSize: '0.9rem'
        }}>{error}</div>}

        <form onSubmit={handleLogin} style={{ textAlign: 'left' }}>
          <div style={{ marginBottom: '20px' }}>
            <label style={{ display: 'block', marginBottom: '8px', fontSize: '0.9rem', color: 'var(--text-secondary)' }}>Email Address</label>
            <div style={{ position: 'relative' }}>
              <Mail size={18} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-secondary)' }} />
              <input 
                type="email" 
                className="input-field" 
                style={{ paddingLeft: '40px' }}
                placeholder="name@college.edu"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
          </div>

          <div style={{ marginBottom: '32px' }}>
            <label style={{ display: 'block', marginBottom: '8px', fontSize: '0.9rem', color: 'var(--text-secondary)' }}>Password</label>
            <div style={{ position: 'relative' }}>
              <Lock size={18} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-secondary)' }} />
              <input 
                type="password" 
                className="input-field" 
                style={{ paddingLeft: '40px' }}
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
          </div>

          <button type="submit" className="btn-primary" style={{ width: '100%', marginBottom: '16px' }} disabled={loading}>
            <LogIn size={20} />
            {loading ? 'Authenticating...' : 'Sign In'}
          </button>

          <button 
            type="button" 
            className="btn-secondary" 
            onClick={handleGoogleLogin}
            disabled={loading}
            style={{ 
              width: '100%', 
              display: 'flex', 
              alignItems: 'center', 
              justifyContent: 'center', 
              gap: '8px',
              padding: '10px',
              borderRadius: '6px',
              background: 'white',
              color: '#0a0c10',
              border: 'none',
              fontWeight: '600',
              cursor: 'pointer'
            }}
          >
            Continue with Google
          </button>
        </form>

        <div style={{ marginTop: '24px', borderTop: '1px solid var(--border-color)', paddingTop: '24px' }}>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem', marginBottom: '12px' }}>Don't have an account?</p>
          <button 
            type="button" 
            onClick={handleDemoAccount}
            style={{ 
              background: 'transparent', 
              border: 'none', 
              color: 'var(--accent-primary)', 
              fontWeight: '600',
              cursor: 'pointer'
            }}
          >
            Use Demo Credentials
          </button>
        </div>
      </div>
    </div>
  );
};

export default Login;
