import React, { useState, useEffect } from 'react';
import { db } from '../../firebase/config';
import { 
  collection, 
  addDoc, 
  onSnapshot, 
  query, 
  where, 
  orderBy, 
  limit, 
  serverTimestamp, 
  updateDoc, 
  doc 
} from 'firebase/firestore';
import { Play, Thermometer, Droplets, Gauge, Beaker, CheckCircle2, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNotifications } from '../Notifications/NotificationSystem';

const Dashboard = () => {
  const { addNotification } = useNotifications();
  const [wasteAmount, setWasteAmount] = useState('');

  const [latestBatch, setLatestBatch] = useState(null);
  const [progress, setProgress] = useState(0);
  const [loading, setLoading] = useState(false);
  const [canStart, setCanStart] = useState(false);

  // Listen for the latest batch
  useEffect(() => {
    const q = query(
      collection(db, "batches"),
      orderBy("startTime", "desc"),
      limit(1)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      if (!snapshot.empty) {
        const batchData = { id: snapshot.docs[0].id, ...snapshot.docs[0].data() };
        setLatestBatch(batchData);
        
        // Rule: New batch starts ONLY when available == 0
        if (batchData.status === 'completed' && batchData.available === 0) {
          setCanStart(true);
        } else if (batchData.status === 'processing') {
          setCanStart(false);
        } else {
          setCanStart(false);
        }
      } else {
        // No batches yet
        setCanStart(true);
      }
    });

    return () => unsubscribe();
  }, []);

  // Handle simulation logic when a batch is in processing
  useEffect(() => {
    let interval;
    if (latestBatch?.status === 'processing' && progress < 100) {
      const duration = 15000; // 15 seconds simulation
      const step = 100; // ms
      const increment = 100 / (duration / step);
      
      interval = setInterval(() => {
        setProgress(prev => {
          if (prev + increment >= 100) {
            clearInterval(interval);
            completeBatch();
            return 100;
          }
          return prev + increment;
        });
      }, step);
    } else if (latestBatch?.status === 'completed') {
      setProgress(100);
    } else if (!latestBatch) {
      setProgress(0);
    }

    return () => clearInterval(interval);
  }, [latestBatch?.status]);

  const completeBatch = async () => {
    if (!latestBatch || latestBatch.status !== 'processing') return;

    const compostGenerated = latestBatch.totalWaste * 0.5;
    const batchRef = doc(db, "batches", latestBatch.id);
    
    try {
      await updateDoc(batchRef, {
        status: 'completed',
        compost: compostGenerated,
        available: compostGenerated,
        endTime: serverTimestamp()
      });
      addNotification(`Batch completed! ${compostGenerated.toFixed(1)}kg of compost generated.`, 'success');
    } catch (err) {

      console.error("Error completing batch", err);
    }
  };

  const startProcess = async (e) => {
    e.preventDefault();
    if (!wasteAmount || isNaN(wasteAmount) || wasteAmount <= 0) return;
    
    setLoading(true);
    const waste = parseFloat(wasteAmount);
    
    try {
      await addDoc(collection(db, "batches"), {
        totalWaste: waste,
        compost: 0,
        available: 0,
        status: "processing",
        startTime: serverTimestamp(),
        sensors: {
          ph: (Math.random() * 2 + 6).toFixed(1), // 6-8
          moisture: (Math.random() * 50 + 30).toFixed(0), // 30-80%
          temperature: (Math.random() * 30 + 30).toFixed(0), // 30-60°C
          ammonia: Math.random() > 0.8 ? "High" : "Normal"
        }
      });
      addNotification(`Process started for ${waste}kg of waste.`, 'info');
      setWasteAmount('');

    } catch (err) {
      console.error("Error starting batch", err);
    } finally {
      setLoading(false);
      setProgress(0);
    }
  };

  const getStatusColor = (status) => {
    switch(status) {
      case 'processing': return 'var(--warning)';
      case 'completed': return 'var(--success)';
      default: return 'var(--text-secondary)';
    }
  };

  return (
    <div className="fade-in">
      <div className="grid">
        {/* Input Section */}
        <section className="glass-panel" style={{ padding: '24px' }}>
          <h3 style={{ marginBottom: '20px', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Gauge size={20} color="var(--accent-primary)" />
            Generate New Compost
          </h3>
          
          {canStart ? (
            <form onSubmit={startProcess}>
              <div style={{ marginBottom: '16px' }}>
                <label style={{ display: 'block', marginBottom: '8px', fontSize: '0.9rem', color: 'var(--text-secondary)' }}>
                  Total waste collected (kg)
                </label>
                <input 
                  type="number" 
                  className="input-field" 
                  placeholder="e.g. 50" 
                  value={wasteAmount}
                  onChange={(e) => setWasteAmount(e.target.value)}
                  disabled={loading}
                  required
                />
              </div>
              <button type="submit" className="btn-primary" style={{ width: '100%' }} disabled={loading}>
                <Play size={18} />
                {loading ? 'Starting...' : 'Start Composting Process'}
              </button>
            </form>
          ) : (
            <div style={{ textAlign: 'center', padding: '20px', color: 'var(--text-secondary)' }}>
              <AlertCircle size={40} style={{ marginBottom: '12px', opacity: 0.5 }} />
              <p>Wait for current batch to be fully distributed before starting a new one.</p>
              {latestBatch?.status === 'completed' && (
                <div style={{ marginTop: '12px', color: 'var(--accent-primary)', fontWeight: '600' }}>
                  Available: {latestBatch.available} kg
                </div>
              )}
            </div>
          )}
        </section>

        {/* Process Tracking */}
        <section className="glass-panel" style={{ padding: '24px', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
          <h3 style={{ alignSelf: 'flex-start', marginBottom: '20px' }}>Active Process</h3>
          
          {latestBatch?.status === 'processing' || (latestBatch?.status === 'completed' && progress === 100) ? (
            <div style={{ textAlign: 'center' }}>
              <div className="circular-progress" style={{ margin: '0 auto 20px' }}>
                <svg viewBox="0 0 100 100">
                  <circle className="bg" cx="50" cy="50" r="45" />
                  <circle 
                    className="fg" 
                    cx="50" 
                    cy="50" 
                    r="45" 
                    style={{ 
                      strokeDasharray: 283, 
                      strokeDashoffset: 283 - (283 * progress) / 100 
                    }} 
                  />
                </svg>
                <div style={{ 
                  position: 'absolute', 
                  top: '50%', 
                  left: '50%', 
                  transform: 'translate(-50%, -50%)',
                  fontSize: '1.2rem',
                  fontWeight: 'bold'
                }}>
                  {Math.round(progress)}%
                </div>
              </div>
              
              <div style={{ 
                color: getStatusColor(latestBatch.status), 
                fontWeight: '600', 
                textTransform: 'uppercase',
                letterSpacing: '1px',
                fontSize: '0.9rem',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '6px'
              }}>
                {latestBatch.status === 'processing' ? 'Processing...' : (
                  <>
                    <CheckCircle2 size={16} />
                    Ready for Distribution
                  </>
                )}
              </div>
            </div>
          ) : (
            <div style={{ textAlign: 'center', color: 'var(--text-secondary)' }}>
              <div style={{ fontSize: '3rem', opacity: 0.1, marginBottom: '10px' }}>⚙️</div>
              <p>No active process</p>
            </div>
          )}
        </section>
      </div>

      {/* Sensor Simulation UI */}
      {latestBatch && (
        <motion.section 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-panel" 
          style={{ marginTop: '20px', padding: '24px' }}
        >
          <h3 style={{ marginBottom: '24px' }}>Simulated Real-Time Sensors</h3>
          <div className="grid">
            <div className="glass-panel" style={{ padding: '16px', background: 'rgba(255,255,255,0.03)', border: 'none' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '10px' }}>
                <span style={{ color: 'var(--text-secondary)', fontSize: '0.9rem' }}>pH Level</span>
                <Beaker size={18} color="#a5d6ff" />
              </div>
              <div style={{ fontSize: '1.8rem', fontWeight: 'bold' }}>{latestBatch.status === 'processing' ? (Math.random() * 0.5 + 6.5).toFixed(1) : latestBatch.sensors?.ph}</div>
              <div style={{ color: 'var(--text-secondary)', fontSize: '0.8rem' }}>Optimal: 6.0 - 8.0</div>
            </div>

            <div className="glass-panel" style={{ padding: '16px', background: 'rgba(255,255,255,0.03)', border: 'none' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '10px' }}>
                <span style={{ color: 'var(--text-secondary)', fontSize: '0.9rem' }}>Moisture</span>
                <Droplets size={18} color="#70d7ff" />
              </div>
              <div style={{ fontSize: '1.8rem', fontWeight: 'bold' }}>{latestBatch.status === 'processing' ? (progress * 0.5 + 30).toFixed(0) : latestBatch.sensors?.moisture}%</div>
              <div style={{ color: 'var(--text-secondary)', fontSize: '0.8rem' }}>Optimal: 40% - 60%</div>
            </div>

            <div className="glass-panel" style={{ padding: '16px', background: 'rgba(255,255,255,0.03)', border: 'none' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '10px' }}>
                <span style={{ color: 'var(--text-secondary)', fontSize: '0.9rem' }}>Temperature</span>
                <Thermometer size={18} color="#ff7b72" />
              </div>
              <div style={{ fontSize: '1.8rem', fontWeight: 'bold' }}>{latestBatch.status === 'processing' ? (progress * 0.3 + 30).toFixed(0) : latestBatch.sensors?.temperature}°C</div>
              <div style={{ color: 'var(--text-secondary)', fontSize: '0.8rem' }}>Optimal: 50°C - 60°C</div>
            </div>

            <div className="glass-panel" style={{ padding: '16px', background: 'rgba(255,255,255,0.03)', border: 'none' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '10px' }}>
                <span style={{ color: 'var(--text-secondary)', fontSize: '0.9rem' }}>Ammonia Gas</span>
                <Gauge size={18} color={latestBatch.sensors?.ammonia === 'High' ? 'var(--warning)' : 'var(--success)'} />
              </div>
              <div style={{ fontSize: '1.8rem', fontWeight: 'bold', color: latestBatch.sensors?.ammonia === 'High' ? 'var(--warning)' : 'var(--success)' }}>
                {latestBatch.sensors?.ammonia || "Normal"}
              </div>
              <div style={{ color: 'var(--text-secondary)', fontSize: '0.8rem' }}>Status: Stable</div>
            </div>
          </div>
        </motion.section>
      )}
    </div>
  );
};

export default Dashboard;
